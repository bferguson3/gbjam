carillon.gb             Carillon Editor v1.2 ROM Image

fruitless.gb            Small demo songs
soundcheck.gb
train.gb
samplecheck.gb
oldschool.gb
chords.gb

fruitless.sav           Demo song SRAM Images
soundcheck.sav          (Transfer to card SRAM)
train.sav

presets.sav             Some preset sounds (Transfer to card SRAM)

carillon.exe            Carillon Editor Utility & related files
carillon.xgb
test16kb.xgb
test32kb.xgb
empty.xsv

sounds <dir>            Sound files for Sound Manager
waveforms <dir>         Alternate set of waveforms (Waveform RAM images)
samples <dir>		Samples for testing (8-bit unsigned raw)

example1.asm            Example of playing music without samples
example2.asm            Example of playing music which uses samples
carillon.inc            Player calls

carillon_help.html      Documentation

sound1.gif              Screenshots
sound2.gif
sound3.gif
menu.gif
block.gif
mono.gif
keyb.gif
hammer.gif
